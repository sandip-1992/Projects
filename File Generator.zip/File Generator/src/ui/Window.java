package ui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import java.awt.Font;
import java.awt.Image;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;

import javax.swing.UIManager;
import javax.swing.border.LineBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import service.Batch;
import service.BatchGenerator;
import service.BatchRepository;
import schedulerService.BuildRepository;
import schedulerService.BuildScheduler;
import schedulerService.WindowController;
import service.ConfigGenerator;

import java.awt.AWTException;
import java.awt.Color;
import java.awt.Component;

import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JTable;

public class Window {

	private JFrame frame;
	private JFrame frame1;
	private JFrame frame2;
	private JFrame frame3;
	private JFrame frame4;
	private JTextField textFieldInput;
	private JTextField textFieldOutput;
	private JTextField textFieldBatchFile;
	private static ArrayList<String> timeList=new ArrayList<String>();
	private JTable table;
	private JButton btnMinimizeToTray;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Window window = new Window();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Window() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 238);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblConfigurationGenerator = new JLabel("Configuration Generator");
		lblConfigurationGenerator.setForeground(new Color(0, 0, 255));
		lblConfigurationGenerator.setFont(new Font("Stencil", Font.PLAIN, 15));
		lblConfigurationGenerator.setBounds(113, 29, 224, 23);
		frame.getContentPane().add(lblConfigurationGenerator);

		JButton btnCreateBatch = new JButton("Create Batch File");
		btnCreateBatch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				frame1.setVisible(true);
				frame2.setVisible(false);
			}
		});
		btnCreateBatch.setForeground(new Color(0, 0, 255));
		btnCreateBatch.setFont(new Font("Arial Narrow", Font.BOLD, 13));
		btnCreateBatch.setBounds(135, 63, 169, 23);
		frame.getContentPane().add(btnCreateBatch);

		JButton btnCreateConfig = new JButton("Create Config File");
		btnCreateConfig.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				frame1.setVisible(false);
				frame2.setVisible(true);
			}
		});
		btnCreateConfig.setForeground(Color.BLUE);
		btnCreateConfig.setFont(new Font("Arial Narrow", Font.BOLD, 13));
		btnCreateConfig.setBounds(135, 108, 169, 23);
		frame.getContentPane().add(btnCreateConfig);

		JButton btnScheduleBuilds = new JButton("Schedule Builds");
		btnScheduleBuilds.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				frame3.setVisible(true);
			}
		});
		btnScheduleBuilds.setForeground(Color.BLUE);
		btnScheduleBuilds.setFont(new Font("Arial Narrow", Font.BOLD, 13));
		btnScheduleBuilds.setBounds(135, 152, 169, 23);
		frame.getContentPane().add(btnScheduleBuilds);

		frame1 = new JFrame();
		frame1.setBounds(100, 100, 543, 284);
		frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame1.getContentPane().setLayout(null);
		frame1.setVisible(false);
		frame1.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

		JLabel lblBatchFileGenerator = new JLabel("Batch File Generator");
		lblBatchFileGenerator.setForeground(new Color(0, 0, 255));
		lblBatchFileGenerator.setFont(new Font("Trajan Pro", Font.BOLD, 15));
		lblBatchFileGenerator.setBounds(165, 37, 235, 23);
		frame1.getContentPane().add(lblBatchFileGenerator);

		JLabel lblInputPath = new JLabel("Input Path");
		lblInputPath.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblInputPath.setBounds(29, 86, 85, 14);
		frame1.getContentPane().add(lblInputPath);

		JLabel lblOutputPath = new JLabel("Output Path");
		lblOutputPath.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblOutputPath.setBounds(29, 128, 85, 14);
		frame1.getContentPane().add(lblOutputPath);

		textFieldInput = new JTextField();
		textFieldInput.setBounds(142, 84, 261, 20);
		frame1.getContentPane().add(textFieldInput);
		textFieldInput.setColumns(10);
		textFieldInput.setEnabled(false);

		textFieldOutput = new JTextField();
		textFieldOutput.setColumns(10);
		textFieldOutput.setBounds(142, 126, 261, 20);
		textFieldOutput.setEnabled(false);
		frame1.getContentPane().add(textFieldOutput);

		JFileChooser chooser = new JFileChooser();
		chooser.setDialogTitle("Select Directory");
		chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		chooser.setAcceptAllFileFilterUsed(false);

		JButton btnBrowseInput = new JButton("Browse");
		btnBrowseInput.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int returnVal = chooser.showOpenDialog((Component)e.getSource());
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					File file = chooser.getSelectedFile();
					try {
						textFieldInput.setText(file.getAbsolutePath()); 
					} catch (Exception ex) {
						System.out.println("problem accessing file"+file.getAbsolutePath());
					}
				} 
				else {
					System.out.println("File access cancelled by user.");
				}       
			}
		});
		btnBrowseInput.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnBrowseInput.setBounds(413, 83, 89, 23);
		frame1.getContentPane().add(btnBrowseInput);

		JButton btnBrowseOutput = new JButton("Browse");
		btnBrowseOutput.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int returnVal = chooser.showOpenDialog((Component)e.getSource());
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					File file = chooser.getSelectedFile();
					try {
						textFieldOutput.setText(file.getAbsolutePath()); 
					} catch (Exception ex) {
						System.out.println("problem accessing file"+file.getAbsolutePath());
					}
				} 
				else {
					System.out.println("File access cancelled by user.");
				}       
			}
		});
		btnBrowseOutput.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnBrowseOutput.setBounds(413, 125, 89, 23);
		frame1.getContentPane().add(btnBrowseOutput);

		JButton btnGenerateBatchFile = new JButton("Generate Batch File");
		btnGenerateBatchFile.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnGenerateBatchFile.setBounds(107, 182, 178, 23);
		frame1.getContentPane().add(btnGenerateBatchFile);

		JButton btnCancel1 = new JButton("Cancel");
		btnCancel1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(true);
				frame1.setVisible(false);
				frame2.setVisible(false);
				textFieldInput.setText("");
				textFieldOutput.setText("");
			}
		});
		btnCancel1.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnCancel1.setBounds(340, 183, 89, 23);
		frame1.getContentPane().add(btnCancel1);
		btnGenerateBatchFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(textFieldInput.getText().equals("")||textFieldOutput.getText().equals(""))
					JOptionPane.showMessageDialog(null,"Please Select Input & Output Folder");
				else{
					new BatchGenerator().generateBatchFile(textFieldInput.getText(), textFieldOutput.getText());
					JOptionPane.showMessageDialog(null,"Batch File Generated");
					frame1.setVisible(false);
					frame.setVisible(true);
				}
			}
		});

		frame2 = new JFrame();
		frame2.setBounds(100, 100, 568, 267);
		frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame2.getContentPane().setLayout(null);
		frame2.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

		JLabel lblConfigFileGenerator = new JLabel("Config File Generator");
		lblConfigFileGenerator.setBounds(185, 37, 235, 23);
		lblConfigFileGenerator.setForeground(new Color(0, 0, 255));
		lblConfigFileGenerator.setFont(new Font("Trajan Pro", Font.BOLD, 15));
		frame2.getContentPane().add(lblConfigFileGenerator);

		JLabel lblBatchFile = new JLabel("Batch File");
		lblBatchFile.setBounds(30, 86, 85, 14);
		lblBatchFile.setFont(new Font("Tahoma", Font.BOLD, 13));
		frame2.getContentPane().add(lblBatchFile);

		JLabel lblTime = new JLabel("Schedule At");
		lblTime.setBounds(30, 123, 96, 14);
		lblTime.setFont(new Font("Tahoma", Font.BOLD, 13));
		frame2.getContentPane().add(lblTime);

		textFieldBatchFile = new JTextField();
		textFieldBatchFile.setBounds(153, 84, 274, 20);
		frame2.getContentPane().add(textFieldBatchFile);
		textFieldBatchFile.setColumns(10);
		textFieldBatchFile.setEnabled(false);

		JComboBox comboBoxHour = new JComboBox();
		for(int i=0;i<24;i++){
			if(i<10)
				comboBoxHour.addItem("0"+Integer.toString(i));
			else
				comboBoxHour.addItem(Integer.toString(i));
		}
		comboBoxHour.setBounds(153, 121, 39, 20);
		frame2.getContentPane().add(comboBoxHour);

		JLabel label = new JLabel(":");
		label.setBounds(202, 124, 46, 14);
		frame2.getContentPane().add(label);

		JComboBox comboBoxMinute = new JComboBox();
		for(int i=0;i<60;i++){
			if(i<10)
				comboBoxMinute.addItem("0"+Integer.toString(i));
			else
				comboBoxMinute.addItem(Integer.toString(i));
		}
		comboBoxMinute.setBounds(212, 121, 39, 20);
		frame2.getContentPane().add(comboBoxMinute);

		JLabel lblBatchCounter = new JLabel(BatchRepository.batches.size()+" Batch File Selected");
		lblBatchCounter.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblBatchCounter.setBounds(30, 168, 203, 14);
		frame2.getContentPane().add(lblBatchCounter);

		JLabel lblTimeCounter = new JLabel(timeList.size()+" Schedule Point");
		lblTimeCounter.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblTimeCounter.setBounds(331, 124, 96, 14);
		frame2.getContentPane().add(lblTimeCounter);

		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String batchFile=textFieldBatchFile.getText();
				if(batchFile.equals(""))
					JOptionPane.showMessageDialog(null, "Please Select A Batch File");
				else if(timeList.size()==0)
					JOptionPane.showMessageDialog(null, "No Schedule Point Defined");
				else{
					String time=comboBoxHour.getSelectedItem().toString()+":"+comboBoxMinute.getSelectedItem().toString();
					System.out.println(batchFile);
					System.out.println(timeList);
					BatchRepository.addBatch(new Batch(batchFile, timeList));
					timeList=new ArrayList<String>();
					lblBatchCounter.setText(BatchRepository.batches.size()+" Batch Files Selected");
					lblTimeCounter.setText(timeList.size()+" Schedule Point");
					textFieldBatchFile.setText("");
				}
			}
		});
		btnAdd.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnAdd.setBounds(440, 119, 89, 23);
		frame2.getContentPane().add(btnAdd);

		JFileChooser chooser2 = new JFileChooser();
		chooser2.setDialogTitle("Select Batch File");
		chooser2.setAcceptAllFileFilterUsed(false);
		FileNameExtensionFilter filter = new FileNameExtensionFilter("XML FILES", "xml");
		chooser2.setFileFilter(filter);
		chooser2.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

		JButton btnGenerateConfigFile = new JButton("Generate Config File");
		btnGenerateConfigFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(BatchRepository.batches.size()==0){
					JOptionPane.showMessageDialog(null, "No Batch Files Added");
				}
				else{
					int returnVal = chooser2.showSaveDialog((Component)e.getSource());
					if (returnVal == JFileChooser.APPROVE_OPTION) {
						File file = chooser2.getSelectedFile();
						System.out.println(file.getAbsolutePath());
						new ConfigGenerator().generateConfig(file.getAbsolutePath());
						JOptionPane.showMessageDialog(null, "Config File Saved As "+file.getAbsolutePath()+"\\config.xml");
						BatchRepository.batches=new ArrayList<Batch>();
						lblBatchCounter.setText(BatchRepository.batches.size()+" Batch File Selected");
						timeList=new ArrayList<String>();
						lblTimeCounter.setText(timeList.size()+" Schedule Point");
						textFieldBatchFile.setText("");
					}
					

				}
			}
		});
		btnGenerateConfigFile.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnGenerateConfigFile.setBounds(243, 165, 184, 23);
		frame2.getContentPane().add(btnGenerateConfigFile);

		JFileChooser chooser1 = new JFileChooser();
		chooser1.setDialogTitle("Select Batch File");
		chooser1.setAcceptAllFileFilterUsed(false);
		FileNameExtensionFilter filter1 = new FileNameExtensionFilter("BATCH FILES", "bat", "batch");
		chooser1.setFileFilter(filter1);

		JButton btnBrowseBatch = new JButton("Browse");
		btnBrowseBatch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int returnVal = chooser1.showOpenDialog((Component)e.getSource());
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					File file = chooser1.getSelectedFile();
					try {
						textFieldBatchFile.setText(file.getAbsolutePath()); 
					} catch (Exception ex) {
						System.out.println("problem accessing file"+file.getAbsolutePath());
					}
				} 
				else {
					System.out.println("File access cancelled by user.");
				}       
			}
		});
		btnBrowseBatch.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnBrowseBatch.setBounds(440, 83, 89, 23);
		frame2.getContentPane().add(btnBrowseBatch);

		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(true);
				frame1.setVisible(false);
				frame2.setVisible(false);
				BatchRepository.batches=new ArrayList<Batch>();
				textFieldBatchFile.setText("");
				comboBoxHour.setSelectedIndex(0);
				comboBoxMinute.setSelectedIndex(0);
				lblBatchCounter.setText(BatchRepository.batches.size()+" Batch File Selected");
				timeList=new ArrayList<String>();
				lblTimeCounter.setText(timeList.size()+" Schedule Point");
			}
		});
		btnCancel.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnCancel.setBounds(440, 165, 89, 23);
		frame2.getContentPane().add(btnCancel);



		JButton btnAddTime = new JButton("Add");
		btnAddTime.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				timeList.add(comboBoxHour.getSelectedItem().toString()+":"+comboBoxMinute.getSelectedItem().toString());
				comboBoxHour.setSelectedIndex(0);
				comboBoxMinute.setSelectedIndex(0);
				lblTimeCounter.setText(timeList.size()+" Schedule Point");
			}
		});
		btnAddTime.setBounds(257, 120, 64, 23);
		frame2.getContentPane().add(btnAddTime);


		frame3 = new JFrame();
		frame3.setBounds(100, 100, 450, 189);
		frame3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame3.getContentPane().setLayout(null);
		frame3.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

		JLabel lblBuildScheduler = new JLabel("Build Scheduler");
		lblBuildScheduler.setForeground(new Color(0, 0, 255));
		lblBuildScheduler.setFont(new Font("Stencil", Font.PLAIN, 15));
		lblBuildScheduler.setBounds(149, 28, 174, 23);
		frame3.getContentPane().add(lblBuildScheduler);

		JFileChooser chooser3 = new JFileChooser();
		chooser3.setDialogTitle("Select Batch File");
		chooser3.setAcceptAllFileFilterUsed(false);
		FileNameExtensionFilter filter2 = new FileNameExtensionFilter("XML FILES", "xml");
		chooser3.setFileFilter(filter2);

		JButton btnLoadConfigXml = new JButton("Load Config XML");
		btnLoadConfigXml.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int returnVal = chooser3.showOpenDialog((Component)e.getSource());
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					File file = chooser3.getSelectedFile();
					System.out.println(file.getAbsolutePath());
					new BuildScheduler().scheduleBuilds(file.getAbsolutePath());
					JOptionPane.showMessageDialog(null, BuildRepository.builds.size()+" Builds Scheduled");
					showFrame4();
					frame3.setVisible(false);
					frame4.setVisible(true);
				} 
			}
		});
		btnLoadConfigXml.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnLoadConfigXml.setBounds(67, 79, 151, 23);
		frame3.getContentPane().add(btnLoadConfigXml);

		JButton btnCancelScheduler = new JButton("Cancel");
		btnCancelScheduler.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame3.setVisible(false);
				frame.setVisible(true);
			}
		});
		btnCancelScheduler.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnCancelScheduler.setBounds(249, 78, 89, 24);
		frame3.getContentPane().add(btnCancelScheduler);


	


	}

	public void showFrame4(){
		frame4 = new JFrame();
		frame4.setBounds(100, 100, 546, WindowController.getWindowWidth());
		frame4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame4.getContentPane().setLayout(null);
		
		JLabel lblScheduledBuilds = new JLabel("Schedulded Builds");
		lblScheduledBuilds.setForeground(new Color(0, 0, 255));
		lblScheduledBuilds.setFont(new Font("Stencil", Font.PLAIN, 15));
		lblScheduledBuilds.setBounds(195, 28, 174, 23);
		frame4.getContentPane().add(lblScheduledBuilds);

		DefaultTableModel tm=new DefaultTableModel();
		tm.setDataVector(WindowController.getTableProperties(),new Object[]{"Builds","Schedules"});
		table = new JTable(tm);
		table.setBounds(50, 71, 440, WindowController.getTableWidth());
	//	frame4.getContentPane().add(table);
		table.setRowHeight(35);
		table.setFont(new Font("Tahoma", Font.BOLD, 11));
		table.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		table.setBackground(new Color(192, 192, 192));
		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
		centerRenderer.setHorizontalAlignment( JLabel.CENTER );
		table.getColumnModel().getColumn(0).setCellRenderer( centerRenderer );
		table.getColumnModel().getColumn(1).setCellRenderer( centerRenderer );
		table.getColumnModel().getColumn(0).setPreferredWidth(160);
		table.getColumnModel().getColumn(1).setPreferredWidth(230);

		JPanel panel = new JPanel();
		panel.setBounds(50, 71, 440, WindowController.getTableWidth());
		frame4.getContentPane().add(panel);
		panel.add(new JScrollPane(table));

		btnMinimizeToTray = new JButton("Minimize to Tray");
		btnMinimizeToTray.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				minimizeToTray();
				frame4.setVisible(false);
			}
		});
		btnMinimizeToTray.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnMinimizeToTray.setBounds(192, 85+WindowController.getTableWidth(), 153, 23);
		frame4.getContentPane().add(btnMinimizeToTray);

	}
	
	public void minimizeToTray(){
		if(!SystemTray.isSupported()){
			System.out.println("System tray is not supported !!! ");
			return ;
		}
		SystemTray systemTray = SystemTray.getSystemTray();
		Image image = Toolkit.getDefaultToolkit().getImage("src/images/2.gif");
		PopupMenu trayPopupMenu = new PopupMenu();
		MenuItem action = new MenuItem("Open");
		action.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame4.setVisible(true);     
			}
		});     
		trayPopupMenu.add(action);
		MenuItem close = new MenuItem("Close");
		close.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);             
			}
		});
		trayPopupMenu.add(close);
		TrayIcon trayIcon = new TrayIcon(image, "SystemTray Demo", trayPopupMenu);
		trayIcon.setImageAutoSize(true);
		try{
			systemTray.add(trayIcon);
		}catch(AWTException awtException){
			awtException.printStackTrace();
		}
	}

}
