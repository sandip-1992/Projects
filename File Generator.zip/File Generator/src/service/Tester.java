package service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new BatchGenerator().generateBatchFile("D:\\it\\DevOps\\Test Repository\\Smoke Suite", "D:\\it");
	}

}
