package schedulerService;

import java.util.Date;

public class ScheduledTasks implements Runnable{
	
	public void run(){
		Date date=new Date();
		System.out.println(date);
		for(int i=0;i<BuildRepository.builds.size();i++){
			for(int j=0;j<BuildRepository.builds.get(i).getTimeToExecute().size();j++){
				if(date.toString().contains(BuildRepository.builds.get(i).getTimeToExecute().get(j)+":"))
					new BuildInitializer().executeProcess(BuildRepository.builds.get(i).getBatchFile());
			}
		}
		for(int i=0;i<BuildRepository.builds.size();i++){
			System.out.println(BuildRepository.builds.get(i).getTimeToExecute());
		}
	}
}
