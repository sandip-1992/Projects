package schedulerService;

import java.util.ArrayList;
import java.util.concurrent.ScheduledExecutorService;

public class BuildRepository {
	public static ArrayList<Build> builds=new ArrayList<Build>();
	public static ArrayList<ScheduledExecutorService> scheduledBuilds= new ArrayList<ScheduledExecutorService>();
	public static void addBuils(Build build){
		builds.add(build);
	}
	public static void addScheduledBuils(ScheduledExecutorService scheduledBuild){
		scheduledBuilds.add(scheduledBuild);
	}
}
