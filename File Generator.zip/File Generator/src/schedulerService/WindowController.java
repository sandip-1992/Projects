package schedulerService;

import java.io.File;
import java.text.SimpleDateFormat;

import javax.swing.JRadioButton;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import service.BatchRepository;

public class WindowController {
	public static int getWindowWidth(){
		System.out.println(BuildRepository.builds.size()+"window");
		return 216+BuildRepository.builds.size()*35;
	}

	public static int getTableWidth(){
		System.out.println(BuildRepository.builds.size()+"table");
		return 35+BuildRepository.builds.size()*35;
	}

	public static Object[][] getTableProperties(){
		Object[][] tableData=new Object[0][0];
		try{
			tableData=new Object[BuildRepository.builds.size()][2];
			for(int i=0;i<BuildRepository.builds.size();i++){
				tableData[i][0]=BuildRepository.builds.get(i).getBatchFile().substring(BuildRepository.builds.get(i).getBatchFile().lastIndexOf('\\')+1);
				String times="";
				for(int j=0;j<BuildRepository.builds.get(i).getTimeToExecute().size();j++){
					if(j>0)
						times=times+", ";
					times=times+BuildRepository.builds.get(i).getTimeToExecute().get(j);
				}
				System.out.println(times+" ******");
				tableData[i][1]=times;
			}
			System.out.println(tableData.length);
		}catch(Exception e){
			e.printStackTrace();
		}
		return tableData;
	}

}
