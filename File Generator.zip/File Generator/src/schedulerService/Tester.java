package schedulerService;
import java.io.File;
import java.lang.Runtime;
public class Tester {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*	new BuildInitializer().initializaBuilds();
		System.out.println(BuildRepository.builds.size());
		new BuildScheduler().scheduleBuilds();*/
		//new BuildInitializer().initializaBuilds("C:\\Users\\SANDIP\\Documents\\config.xml");
		try{
		//	String[] command = {"cmd.exe", "/C", "Start", "D:\\Smoke Suite.bat"};
		//	Process p =  Runtime.getRuntime().exec(command);
		//	Process p = Runtime.getRuntime().exec("D:\\Smoke Suite.cmd");
		//	Process run = Runtime.getRuntime().exec("cmd.exe", "/c", "Start", "D:\\Smoke Suite.bat");
			Process p =  Runtime.getRuntime().exec("cmd /c start D:\\SmokeSuite.bat");
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
