import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;



public class DataChartCreator {
	
	public JFreeChart createChartPanel(String filePath,String name) {
	    String chartTitle = name;
	    String categoryAxisLabel = "Sequence";
	    String valueAxisLabel = "Pass Percentage";
	    CategoryDataset dataset = createDataSet(filePath);
	    JFreeChart chart = ChartFactory.createLineChart(chartTitle, categoryAxisLabel, valueAxisLabel, dataset,PlotOrientation.VERTICAL , false, false, false);
	    CategoryPlot plot=(CategoryPlot)chart.getPlot();
	    LineAndShapeRenderer renderer = (LineAndShapeRenderer) plot.getRenderer();
	    renderer.setBaseShapesVisible(true);
	    return chart;
	}
	
	public CategoryDataset createDataSet(String filePath){
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		try{
			File historyFile = new File(filePath);
			DocumentBuilderFactory dbFactory1 = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder1 = dbFactory1.newDocumentBuilder();
			Document historyDoc = dBuilder1.parse(historyFile);
			historyDoc.getDocumentElement().normalize();
			NodeList buildList=historyDoc.getElementsByTagName("build");
			for(int i=0;i<buildList.getLength();i++){
				Element build=(Element)buildList.item(i);
				String percentage=build.getElementsByTagName("percentage").item(0).getTextContent();
				String timestamp=build.getElementsByTagName("timestamp").item(0).getTextContent();
				System.out.println(timestamp.length());
				System.out.println(timestamp.substring(0,6)+timestamp.substring(8,10));
				dataset.addValue(Double.parseDouble(percentage), "Scenario", timestamp.substring(0,6)+timestamp.substring(8,10));
			}
			return dataset;
		}catch(Exception e){
			e.printStackTrace();
			return dataset;
		}
	}
}
