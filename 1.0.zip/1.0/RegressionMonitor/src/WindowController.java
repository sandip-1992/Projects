import java.io.File;
import java.text.SimpleDateFormat;

import javax.swing.JRadioButton;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;



public class WindowController {
	private static String propertyLocation="C:\\RegressionResults\\";
	public static int getTableBound(){
		int tableBound=0;
		try{
			File inputFile = new File(propertyLocation+"appProperties.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("application");
			tableBound=nList.getLength()*35;
			System.out.println(tableBound);
		}catch(Exception e){
			e.printStackTrace();
		}
		if(tableBound<=350)
			return tableBound;
		else
			return 350;
	}
	public static int getWindowBound(){
		int windowBound=225;
		try{
			File inputFile = new File(propertyLocation+"appProperties.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("application");
			windowBound=270+35*nList.getLength();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(windowBound<=620)
			return windowBound;
		else
			return 620;
	}

	public static Object[][] getTableProperties(){
		Object[][] appData=new Object[0][0];
		try{
			File inputFile = new File(propertyLocation+"appProperties.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
			NodeList nodeList=doc.getElementsByTagName("repository");
			String repository=nodeList.item(0).getTextContent();
			System.out.println(repository);
			NodeList nList = doc.getElementsByTagName("application");
			appData=new Object[nList.getLength()][4];
			for(int i=0;i<nList.getLength();i++){
				appData[i][0]=new JRadioButton(nList.item(i).getTextContent());
				File file = new File(WindowController.getRepository()+nList.item(i).getTextContent()+"\\Reports\\cucumber\\index.html");
				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
				System.out.println("After Format : " + sdf.format(file.lastModified()));
				appData[i][1]=sdf.format(file.lastModified());
				int[][] result= new ResultProcessor().getResult(WindowController.getRepository()+nList.item(i).getTextContent()+"\\Reports\\cucumber.json");
				int totalTests=result[1][0];
				int passedTests=result[1][1];
				int failedTests=result[1][2];
				if(failedTests==0)
					appData[i][2]="Passed";
				else
					appData[i][2]="Failed";
				int percentage=(passedTests*100)/totalTests;
				String resultText="Passed : "+Integer.toString(passedTests)+" ; Failed : "+Integer.toString(failedTests)+" ; "+Integer.toString(percentage)+" % Passed";
				appData[i][3]=resultText;
			}
			System.out.println(appData.length);
		}catch(Exception e){
			e.printStackTrace();
		}
		return appData;
	}

	public static String getRepository(){
		String repository=null;
		try{
			File inputFile = new File(propertyLocation+"appProperties.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
			NodeList nodeList=doc.getElementsByTagName("repository");
			repository=nodeList.item(0).getTextContent();
		}catch(Exception e){
			e.printStackTrace();
		}
		return repository;
	}
	
	public static boolean loadRepository(String folderPath){
		try{
			File appProperties=new File(folderPath+"\\appProperties.xml");
			if(appProperties.exists()){
				propertyLocation=folderPath+"\\";
				return true;
			}
			else
				return false;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
	
}
