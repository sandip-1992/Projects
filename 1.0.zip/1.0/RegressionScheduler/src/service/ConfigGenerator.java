package service;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class ConfigGenerator {

	public void generateConfig(String path){
		try{
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.newDocument();
			Element rootElement = doc.createElement("Batches");
			doc.appendChild(rootElement);
			for(int i=0;i<BatchRepository.batches.size();i++){
				Element batch = doc.createElement("Batch");
				rootElement.appendChild(batch);
				Element batchPath=doc.createElement("BatchPath");
				batchPath.setTextContent(BatchRepository.batches.get(i).getBatchName());
				batch.appendChild(batchPath);
				for(int j=0;j<BatchRepository.batches.get(i).getTime().size();j++){
					Element scheduledTime=doc.createElement("ScheduledTime");
					scheduledTime.setTextContent(BatchRepository.batches.get(i).getTime().get(j));
					batch.appendChild(scheduledTime);
				}
			}
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(path+"\\config.xml"));
			transformer.transform(source, result);
			System.out.println("File saved!");

		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
