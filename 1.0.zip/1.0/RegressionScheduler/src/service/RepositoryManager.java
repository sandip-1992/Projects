package service;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import schedulerService.WindowController;

public class RepositoryManager {
	public String createRepository(String folderPath){
		try{
			File repository=new File(folderPath);
			if(repository.list().length!=0)
				return "Selected Folder Is Not Empty";
			else{
				DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
				Document doc = docBuilder.newDocument();
				Element rootElement = doc.createElement("applications");
				doc.appendChild(rootElement);
				Element repositoryLocation=doc.createElement("repository");
				repositoryLocation.setTextContent(folderPath+"\\");
				rootElement.appendChild(repositoryLocation);
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				DOMSource source = new DOMSource(doc);
				StreamResult result = new StreamResult(new File(folderPath+"\\appProperties.xml"));
				transformer.transform(source, result);
				WindowController.setPropertyLocation(folderPath+"\\");
				return "Repository Created";
			}
		}catch(Exception e){
			e.printStackTrace();
			return "Error While Creating Repository";

		}
	}

	public boolean loadRepository(String folderPath){
		try{
			File appProperties=new File(folderPath+"\\appProperties.xml");
			if(appProperties.exists()){
				WindowController.setPropertyLocation(folderPath+"\\");
				return true;
			}
			else
				return false;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}

	public boolean addToRepository(String filePath){
		try{
			File inputFile1 = new File(filePath);
			DocumentBuilderFactory dbFactory1 = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder1 = dbFactory1.newDocumentBuilder();
			Document doc1 = dBuilder1.parse(inputFile1);
			doc1.getDocumentElement().normalize();
			NodeList batches = doc1.getElementsByTagName("BatchPath");
			System.out.println(batches.getLength());
			String applications[]= new String[batches.getLength()];
			for(int i=0;i<batches.getLength();i++){
				String batchPath=batches.item(i).getTextContent();
				String application=batchPath.substring(batchPath.lastIndexOf('\\')+1,batchPath.lastIndexOf('.'));
				System.out.println(application);
				applications[i]=application;
			}
			File inputFile = new File(WindowController.getRepository()+"appProperties.xml");
			System.out.println(WindowController.getRepository()+"appProperties.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
			NodeList allApplications = doc.getElementsByTagName("application");
			for(int i=0;i<applications.length;i++){
				boolean isExists=false;
				for(int j=0;j<allApplications.getLength();j++){
					if(applications[i].equalsIgnoreCase(allApplications.item(j).getTextContent())){
						isExists=true;
						break;
					}
				}
				if(isExists==false){
					Element rootElement = doc.getDocumentElement();
					Element newApplication=doc.createElement("application");
					newApplication.setTextContent(applications[i]);
					rootElement.appendChild(newApplication);
					new File(WindowController.getRepository()+applications[i]).mkdir();
					new File(WindowController.getRepository()+applications[i]+"\\Reports").mkdir();
					new File(WindowController.getRepository()+applications[i]+"\\Screenshots").mkdir();
					new File(WindowController.getRepository()+applications[i]+"\\Logs").mkdir();
					DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
					DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
					Document doc2 = docBuilder.newDocument();
					Element rootElement1 = doc2.createElement("builds");
					doc2.appendChild(rootElement1);
					TransformerFactory transformerFactory = TransformerFactory.newInstance();
					Transformer transformer = transformerFactory.newTransformer();
					DOMSource source = new DOMSource(doc2);
					StreamResult result = new StreamResult(new File(WindowController.getRepository()+applications[i]+"\\history.xml"));
					transformer.transform(source, result);
					System.out.println("File saved!");
				}
			}
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(WindowController.getRepository()+"\\appProperties.xml"));
			transformer.transform(source, result);
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}

}
