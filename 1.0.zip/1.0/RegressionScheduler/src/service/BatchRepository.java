package service;

import java.util.ArrayList;

public class BatchRepository {
	public static ArrayList<Batch> batches=new ArrayList<Batch>();
	public static void addBatch(Batch batch){
		batches.add(batch);
	}
}
