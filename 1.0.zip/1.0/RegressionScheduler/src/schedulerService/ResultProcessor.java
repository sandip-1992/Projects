package schedulerService;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ResultProcessor {

	public int[][]  getResult(String filePath) {
		int[] features={0,0,0};
		int[] scenarios={0,0,0};
		int[] steps={0,0,0,0};
		
		JSONParser parser = new JSONParser();
		try {
			Object obj = parser.parse(new FileReader(filePath));
			JSONArray allFeatures=(JSONArray)obj;
			features[0]=allFeatures.size();
			int passedFeatures=0;
			for(int i=0;i<allFeatures.size();i++){
				JSONObject feature=(JSONObject)allFeatures.get(i);
				JSONArray allScenarios=(JSONArray)feature.get("elements");
				scenarios[0]=scenarios[0]+allScenarios.size();
				int totalScenarios=allScenarios.size();
				int passedScenarios=0;
				for(int j=0;j<allScenarios.size();j++){
					JSONObject scenario=(JSONObject)allScenarios.get(j);
					JSONArray allSteps=(JSONArray)scenario.get("steps");
					steps[0]=steps[0]+allSteps.size();
					int totalSteps=allSteps.size();
					int passedSteps=0;
					int failedSteps=0;
					int skippedSteps=0;
					for(int k=0;k<allSteps.size();k++){
						JSONObject step=(JSONObject)allSteps.get(k);
						JSONObject result=(JSONObject)step.get("result");
					//	System.out.println(result.get("status").toString());
						if(result.get("status").toString().equalsIgnoreCase("passed")){
							passedSteps++;
						}
						if(result.get("status").toString().equalsIgnoreCase("failed")){
							failedSteps++;
						}
						if(result.get("status").toString().equalsIgnoreCase("skipped")){
							skippedSteps++;
						}
					
					}
				//	System.out.println(passedSteps);
					steps[1]=steps[1]+passedSteps;
					steps[2]=steps[2]+failedSteps;
					steps[3]=steps[3]+skippedSteps;
					if(passedSteps==totalSteps){
						passedScenarios++;
						scenarios[1]=scenarios[1]+1;
					}
				}
				if(passedScenarios==totalScenarios)
					passedFeatures++;
			}
			features[1]=passedFeatures;
			scenarios[2]=scenarios[0]-scenarios[1];
			features[2]=features[0]-features[1];
			return new int[][]{features,scenarios,steps};
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new int[][]{features,scenarios,steps};
		}
	}
	
	public double getPercentage(String filePath){
		int[][] result=getResult(filePath);
		return 100*(double)result[1][1]/(double)result[1][0];
	}

}
