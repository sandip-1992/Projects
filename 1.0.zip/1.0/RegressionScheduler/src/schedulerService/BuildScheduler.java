package schedulerService;

import java.util.Timer;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import service.RepositoryManager;

public class BuildScheduler {
	private static ScheduledExecutorService scheduledExecutorServiceHistory;
	
	public static ScheduledExecutorService getScheduledExecutorServiceHistory() {
		return scheduledExecutorServiceHistory;
	}

	public void scheduleBuilds(String configPath){
		try{
			new RepositoryManager().addToRepository(configPath);
			new BuildInitializer().initializaBuilds(configPath);
			ScheduledExecutorService scheduledExecutorService = Executors.newScheduledThreadPool(5);
			scheduledExecutorService.scheduleWithFixedDelay(new ScheduledTasks(), 2,60, TimeUnit.SECONDS);
			//	System.out.println("result = " + scheduledFuture.get());
			BuildRepository.addScheduledBuils(scheduledExecutorService);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void scheduleHistoryTasks(){
		try{
			scheduledExecutorServiceHistory = Executors.newScheduledThreadPool(5);
			scheduledExecutorServiceHistory.scheduleWithFixedDelay(new ScheduledHistoryTasks(), 2,60, TimeUnit.SECONDS);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void stopHistoryTasks(){
		try{
			scheduledExecutorServiceHistory.shutdown();
			scheduledExecutorServiceHistory=null;
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
}
