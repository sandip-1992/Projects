package schedulerService;
import java.io.File;
import java.text.SimpleDateFormat;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class HistoryTask {
	private static String propertyLocation="C:\\RegressionResults\\";
	public void takeHistory(){
		try{
			File inputFile = new File(propertyLocation+"appProperties.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
			NodeList nodeList=doc.getElementsByTagName("repository");
			String repository=nodeList.item(0).getTextContent();
			System.out.println(repository);
			NodeList nList = doc.getElementsByTagName("application");
			for(int i=0;i<nList.getLength();i++){
				File historyFile = new File(WindowController.getRepository()+nList.item(i).getTextContent()+"\\history.xml");
				DocumentBuilderFactory dbFactory1 = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder1 = dbFactory1.newDocumentBuilder();
				Document historyDoc = dBuilder1.parse(historyFile);
				historyDoc.getDocumentElement().normalize();
				NodeList buildList=historyDoc.getElementsByTagName("build");
				System.out.println(buildList.item(buildList.getLength()-4));
				Element lastBuild=(Element)buildList.item(buildList.getLength()-1);
				String lastTimestamp=lastBuild.getElementsByTagName("timestamp").item(0).getTextContent();
				File file = new File(WindowController.getRepository()+nList.item(i).getTextContent()+"\\Reports\\cucumber.json");
				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
				System.out.println(sdf.format(file.lastModified()));
				String currentTimestamp=sdf.format(file.lastModified());
				System.out.println(currentTimestamp);
				if(!currentTimestamp.equals(lastTimestamp)){
					if(buildList.getLength()==10){
						Element root=historyDoc.getDocumentElement();
						root.removeChild(buildList.item(0));
					}
					Element build=historyDoc.createElement("build");
					Element percentage=historyDoc.createElement("percentage");
					percentage.setTextContent(Double.toString(new ResultProcessor().getPercentage(WindowController.getRepository()+nList.item(i).getTextContent()+"\\Reports\\cucumber.json")));
					Element timestamp=historyDoc.createElement("timestamp");
					timestamp.setTextContent(currentTimestamp);
					build.appendChild(percentage);
					build.appendChild(timestamp);
					Element root=historyDoc.getDocumentElement();
					root.appendChild(build);
					TransformerFactory transformerFactory = TransformerFactory.newInstance();
					Transformer transformer = transformerFactory.newTransformer();
					DOMSource source = new DOMSource(historyDoc);
					StreamResult result = new StreamResult(new File(WindowController.getRepository()+nList.item(i).getTextContent()+"\\history.xml"));
					transformer.transform(source, result);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
