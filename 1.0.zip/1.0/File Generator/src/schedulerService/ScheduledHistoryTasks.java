package schedulerService;

import java.util.Date;

public class ScheduledHistoryTasks implements Runnable{

	public void run(){
		Date date=new Date();
		System.out.println(date);
		if(date.toString().contains("00:00:"))
			new HistoryTask().takeHistory();
	}
}
