package schedulerService;

import java.util.Timer;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public class BuildScheduler {
	public void scheduleBuilds(String configPath){
		try{
			new BuildInitializer().initializaBuilds(configPath);
			ScheduledExecutorService scheduledExecutorService = Executors.newScheduledThreadPool(5);
			scheduledExecutorService.scheduleWithFixedDelay(new ScheduledTasks(), 2,60, TimeUnit.SECONDS);
			//	System.out.println("result = " + scheduledFuture.get());
			BuildRepository.addScheduledBuils(scheduledExecutorService);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void scheduleHistoryTasks(){
		try{
			ScheduledExecutorService scheduledExecutorService = Executors.newScheduledThreadPool(5);
			scheduledExecutorService.scheduleWithFixedDelay(new ScheduledHistoryTasks(), 2,60, TimeUnit.SECONDS);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
