package service;

import java.io.File;
import java.io.PrintWriter;

public class BatchGenerator {
	public void generateBatchFile(String inputPath, String outputPath){
		try {
			String fileName=inputPath.substring(inputPath.lastIndexOf('\\')+1).replaceAll(" ", "");
			File file = new File(outputPath+"\\"+fileName+".bat");
			file.createNewFile();
			PrintWriter writer = new PrintWriter(file, "UTF-8");
			writer.println(Character.toString(inputPath.charAt(0))+":");
			writer.println("cd "+inputPath);
			writer.println("mvn test");
			writer.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
