package service;

import java.util.ArrayList;

public class Batch {
	private String batchName;
	private ArrayList<String> times;
	public Batch(String batchName, ArrayList<String> times) {
		super();
		this.batchName = batchName;
		this.times = times;
	}
	public String getBatchName() {
		return batchName;
	}
	public ArrayList<String> getTime() {
		return times;
	}
}
