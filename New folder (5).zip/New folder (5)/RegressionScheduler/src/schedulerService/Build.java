package schedulerService;

import java.util.ArrayList;

public class Build {
	private String batchFile;
	private ArrayList<String> timesToExecute;
	public Build(String batchFile, ArrayList<String> timesToExecute) {
		super();
		this.batchFile = batchFile;
		this.timesToExecute = timesToExecute;
	}
	public String getBatchFile() {
		return batchFile;
	}
	public ArrayList<String> getTimeToExecute() {
		return timesToExecute;
	}
	
}
