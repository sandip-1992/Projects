package schedulerService;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class BuildInitializer {
	public String initializaBuilds(String configPath){
		try{
			File inputFile = new File(configPath);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
			NodeList batches = doc.getElementsByTagName("Batch");
			if(batches.getLength()==0)
				return "No Batch File Found";
			else{
				for(int i=0;i<batches.getLength();i++){
					//Node e=nList.item(0).getChildNodes().item(0);
					NodeList batchProperties=batches.item(i).getChildNodes();
					String batchPath=batchProperties.item(0).getTextContent();
					ArrayList<String> timesToExecute=new ArrayList<String>();
					for(int j=1;j<batchProperties.getLength();j++){
						timesToExecute.add(batchProperties.item(j).getTextContent());
					}
					System.out.println(batchPath);
					System.out.println(timesToExecute);
					BuildRepository.addBuils(new Build(batchPath,timesToExecute));
				}
				return "";
			}
		}catch(Exception e){
			e.printStackTrace();
			return "";
		}
	}
	
	public void executeProcess(String batFile){
		try {
			Process p =  Runtime.getRuntime().exec("cmd /c start "+batFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
