import java.awt.Color;
import java.awt.Font;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;

public class PieChartCreator {
	public static JFreeChart createChart(int[] values,String type) {
		PieDataset dataset=createDataset(values, type);

		JFreeChart chart = ChartFactory.createPieChart(
				type+" Statistics",  // chart title
				dataset,             // data
				true,               // include legend
				true,
				false
				);

		PiePlot plot = (PiePlot) chart.getPlot();
		plot.setLabelFont(new Font("SansSerif", Font.PLAIN, 12));
		plot.setNoDataMessage("No data available");
		plot.setCircular(false);
		plot.setLabelGap(0.02);
		plot.setIgnoreZeroValues(true);
		plot.setSectionPaint("Passed", Color.GREEN);
		plot.setSectionPaint("Failed", Color.RED);
		if(type.equals("Step"))
			plot.setSectionPaint("Skipped", Color.BLUE);
		return chart;

	}

	private static PieDataset createDataset(int[] values,String type) {
		DefaultPieDataset dataset = new DefaultPieDataset();
		if(type.equals("Feature")||type.equals("Scenario")){
			dataset.setValue("Passed", new Double(values[1]));
			dataset.setValue("Failed", new Double(values[2]));
		}
		if(type.equals("Step")){
			dataset.setValue("Passed", new Double(values[1]));
			dataset.setValue("Failed", new Double(values[2]));
			dataset.setValue("Skipped", new Double(values[3]));
			
		}
		return dataset;        
	}
}
