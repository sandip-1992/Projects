package service;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import schedulerService.WindowController;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			File inputFile1 = new File("C:\\config.xml");
			DocumentBuilderFactory dbFactory1 = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder1 = dbFactory1.newDocumentBuilder();
			Document doc1 = dBuilder1.parse(inputFile1);
			doc1.getDocumentElement().normalize();
			NodeList batches = doc1.getElementsByTagName("BatchPath");
			System.out.println(batches.getLength());
			String applications[]= new String[batches.getLength()];
			for(int i=0;i<batches.getLength();i++){
				String batchPath=batches.item(i).getTextContent();
				String application=batchPath.substring(batchPath.lastIndexOf('\\')+1,batchPath.lastIndexOf('.'));
				System.out.println(application);
				applications[i]=application;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
