function addRow() {
          
    var myName = document.getElementById("name");
    var age = document.getElementById("age");
    var table = document.getElementById("myTableData");
 
    var rowCount = table.rows.length;
    var row = table.insertRow(rowCount);
 
    row.insertCell(0).innerHTML= '<input type="button" value = "Delete" onClick="Javacsript:deleteRow(this)">';
    row.insertCell(1).innerHTML= myName.value;
    row.insertCell(2).innerHTML= age.value;
 
}

function checkData(){
    var myName = document.getElementById("name");
    var age = document.getElementById("age");
	
     if ((myName.value == ''||myName.length == 0||myName==null)||(age.value == ''||age.length == 0||age==null)) {
        alert("Field is empty");
    }
	else
		addRow();
}
 