import java.awt.Color;
import java.awt.Component;
import java.awt.Desktop;
import java.awt.EventQueue;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;

import java.awt.Component;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.event.TableModelEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import java.awt.Font;
import javax.swing.JPanel;

class RadioButtonRenderer implements TableCellRenderer {
	public Component getTableCellRendererComponent(JTable table, Object value,
			boolean isSelected, boolean hasFocus, int row, int column) {
		if (value == null)
			return null;
		Component cell=(Component)value;
		cell.setBackground(new Color(192, 192, 192));
		return (Component) cell;
	}
}

class RadioButtonEditor extends DefaultCellEditor implements ItemListener {
	private JRadioButton button;

	public RadioButtonEditor(JCheckBox checkBox) {
		super(checkBox);
	}
	public Component getTableCellEditorComponent(JTable table, Object value,
			boolean isSelected, int row, int column) {
		if (value == null)
			return null;
		button = (JRadioButton) value;
		button.addItemListener(this);
		return (Component) value;
	}
	public Object getCellEditorValue() {
		button.removeItemListener(this);
		return button;
	}

	public void itemStateChanged(ItemEvent e) {
		super.fireEditingStopped();
	}
}

public class Window {

	private JFrame frame;
	private JTable table;
	private JButton btnNewButton;
	private JButton btnNewButton_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Window window = new Window();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Window() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	
	public boolean isCellEditable(int row, int column){
        return false;
    }
	
	
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 806, WindowController.getWindowBound());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);


	/*	JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(84, 77, 625, WindowController.getTableBound()+35);
		frame.getContentPane().add(scrollPane);
		scrollPane.setLayout(null);*/

		DefaultTableModel tm=new DefaultTableModel(){
			@Override 
			public boolean isCellEditable(int row, int column)
		    {
		        return column==0;
		    }
		};
		tm.setDataVector(WindowController.getTableProperties(),new Object[]{"Application","Last Run","Status"});
		table = new JTable(tm){
			public void tableChanged(TableModelEvent e) {
				super.tableChanged(e);
				repaint();
			}
		};
		
	
		
		table.getColumnModel().getColumn(0).setPreferredWidth(220);
		table.getColumnModel().getColumn(1).setPreferredWidth(220);
		table.getColumnModel().getColumn(2).setPreferredWidth(100);
		table.setFont(new Font("Tahoma", Font.BOLD, 11));
		table.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		table.setBackground(new Color(192, 192, 192));
		ButtonGroup radioGroups=new ButtonGroup();
		for(int i=0;i<table.getRowCount();i++){
			radioGroups.add((JRadioButton)tm.getValueAt(i, 0));
		}
		table.setRowHeight(35);
		table.getColumn("Application").setCellRenderer(
				new RadioButtonRenderer());
		table.getColumn("Application").setCellEditor(
				new RadioButtonEditor(new JCheckBox()));
		System.out.println(WindowController.getTableBound());
		table.setBounds(0,0, 625, WindowController.getTableBound()+35);



		btnNewButton = new JButton("View Report");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(int i=0;i<table.getRowCount();i++){
					JRadioButton r=(JRadioButton)table.getModel().getValueAt(i, 0);
					if(r.isSelected()){
						System.out.println(table.getModel().getValueAt(i, 1));
						System.out.println(WindowController.getRepository()+r.getText()+"\\target\\cucumber\\index.html");
						File htmlFile = new File(WindowController.getRepository()+r.getText()+"\\target\\cucumber\\index.html");
						try {
							Desktop.getDesktop().browse(htmlFile.toURI());
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
			}
		});
		btnNewButton.setBounds(152, WindowController.getWindowBound()-120, 151, 23);
		frame.getContentPane().add(btnNewButton);

		btnNewButton_1 = new JButton("View Artefacts");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(int i=0;i<table.getRowCount();i++){
					JRadioButton r=(JRadioButton)table.getModel().getValueAt(i, 0);
					if(r.isSelected()){
						System.out.println(table.getModel().getValueAt(i, 1));
						System.out.println(WindowController.getRepository()+r.getText()+"\\target\\screenshots\\ScreenshotDocs");
						File file = new File(WindowController.getRepository()+r.getText()+"\\target\\screenshots\\ScreenshotDocs");
						try {
							Desktop.getDesktop().open(file);
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
			}
		});
		btnNewButton_1.setBounds(402, WindowController.getWindowBound()-120, 151, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JPanel panel = new JPanel();
		panel.setBounds(85, 77, 625, WindowController.getTableBound()+35);
		frame.getContentPane().add(panel);
		panel.add(new JScrollPane(table));

	}



}
