

import java.io.File;
import java.util.Arrays;

import org.apache.maven.shared.invoker.DefaultInvocationRequest;
import org.apache.maven.shared.invoker.DefaultInvoker;
import org.apache.maven.shared.invoker.InvocationRequest;
import org.apache.maven.shared.invoker.Invoker;

public class Tester {

	public static void main(String[] args) {
		try {
			/*ProcessBuilder builder = new ProcessBuilder(
					"cmd.exe", "/c", "cd \"C:\\Program Files\\Microsoft SQL Server\" && dir");
			 builder.redirectErrorStream(true);
			    Process p = builder.start();
			    BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
		        String line;
		        while (true) {
		            line = r.readLine();
		            if (line == null) { break; }
		            System.out.println(line);
		        }*/
			/*Runtime rt = Runtime.getRuntime();
			rt.exec("cmd.exe /d cd \"\\it\\devops\\test repsoitory\\smoke suite\" mvn test ");*/
			System.out.println("Hello");
			InvocationRequest request = new DefaultInvocationRequest();
			request.setPomFile( new File( "D:/it/devops/test repository/smoke suite/pom.xml" ) );
			request.setGoals( Arrays.asList( "clean", "install" ) );

			Invoker invoker = new DefaultInvoker();
			invoker.execute( request );
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
